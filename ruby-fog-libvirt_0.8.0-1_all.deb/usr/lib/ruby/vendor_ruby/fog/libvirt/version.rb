module Fog
  module Libvirt
    VERSION = '0.8.0'
  end
end
