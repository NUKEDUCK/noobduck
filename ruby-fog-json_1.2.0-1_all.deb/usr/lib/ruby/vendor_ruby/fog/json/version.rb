module Fog
  module Json
    VERSION = "1.2.0"
  end
end
