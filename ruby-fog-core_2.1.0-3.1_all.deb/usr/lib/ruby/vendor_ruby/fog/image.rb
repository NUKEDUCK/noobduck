module Fog
  module Image
    extend Fog::ServicesMixin
  end
end
