module Fog
  module Core
    VERSION = "2.1.0"
  end
end
