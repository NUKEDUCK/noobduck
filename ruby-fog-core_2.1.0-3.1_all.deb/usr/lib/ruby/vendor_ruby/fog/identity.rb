module Fog
  module Identity
    extend Fog::ServicesMixin
  end
end
