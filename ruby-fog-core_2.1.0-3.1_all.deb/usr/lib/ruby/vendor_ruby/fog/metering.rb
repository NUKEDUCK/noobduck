module Fog
  module Metering
    extend Fog::ServicesMixin
  end
end
