module Fog
  module Orchestration
    extend Fog::ServicesMixin
  end
end
