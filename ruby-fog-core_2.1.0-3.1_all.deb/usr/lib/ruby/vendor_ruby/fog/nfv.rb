module Fog
  module NFV
    extend Fog::ServicesMixin
  end
end
