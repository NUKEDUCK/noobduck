module MiniTest::Expectations
  infect_an_assertion :assert_match_schema, :must_match_schema, :reverse
end
