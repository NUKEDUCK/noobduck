module Fog
  module CDN
    extend Fog::ServicesMixin
  end
end
