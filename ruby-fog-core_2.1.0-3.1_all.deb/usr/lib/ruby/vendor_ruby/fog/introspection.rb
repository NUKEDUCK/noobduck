module Fog
  module Introspection
    extend Fog::ServicesMixin
  end
end
