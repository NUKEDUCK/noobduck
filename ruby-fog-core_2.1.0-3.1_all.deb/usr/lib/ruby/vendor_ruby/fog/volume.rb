module Fog
  module Volume
    extend Fog::ServicesMixin
  end
end
