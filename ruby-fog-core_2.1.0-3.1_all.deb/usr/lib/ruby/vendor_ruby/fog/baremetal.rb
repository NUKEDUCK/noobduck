module Fog
  module Baremetal
    extend Fog::ServicesMixin
  end
end
