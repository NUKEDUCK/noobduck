module Net; class SCP

  class Error < RuntimeError; end

end; end