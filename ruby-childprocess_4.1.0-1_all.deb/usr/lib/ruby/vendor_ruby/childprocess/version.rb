module ChildProcess
  VERSION = '4.1.0'
end
