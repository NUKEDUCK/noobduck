module Log4r
  Log4rVersion = [1, 1, 10].join '.' # deprecate?
  VERSION = Log4rVersion
end
