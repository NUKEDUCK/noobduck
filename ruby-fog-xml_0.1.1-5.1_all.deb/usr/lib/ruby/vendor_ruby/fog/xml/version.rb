module Fog
  module Xml
    VERSION = "0.1.1"
  end
end
