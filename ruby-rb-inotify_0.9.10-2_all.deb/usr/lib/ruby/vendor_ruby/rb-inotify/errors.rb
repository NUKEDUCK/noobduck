module INotify
  class QueueOverflowError < RuntimeError; end
end
